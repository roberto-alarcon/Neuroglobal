<?php

$sliderOptions = array(
    'main' => array(
        'title' => __('Main Settings', MPSL_TEXTDOMAIN),
        'icon' => null,
        'description' => __('Main description', MPSL_TEXTDOMAIN),
        'options' => array(
            'title' => array(
                'type' => 'text',
                'label' => __('Slider title *:', MPSL_TEXTDOMAIN),
                'description' => __('The title of the slider. Example: Slider1', MPSL_TEXTDOMAIN),
                'default' => __('New Slider', MPSL_TEXTDOMAIN),
                'disabled' => false,
                'required' => true,
            ),
            'alias' => array(
                'type' => 'alias',
                'label' => __('Slider alias *:', MPSL_TEXTDOMAIN),
                'alias' => 'shortcode',
                'description' => __('The alias that will be used in shortcode for embedding the slider. Alias must be unique. Example: slider1', MPSL_TEXTDOMAIN),
                'default' => '',
                'disabled' => false,
                'required' => true,
            ),
            'shortcode' => array(
                'type' => 'shortcode',
                'label' => __('Slider shortcode:', MPSL_TEXTDOMAIN),
                'description' => 'Copy this shortocode and paste to your page.',
                'default' => '',
                'readonly' => true,
//                'disabled' => false,
            ),
            'full_width' => array(
                'type' => 'checkbox',
                'label2' => __('Force Full Width', MPSL_TEXTDOMAIN),
                'description' => __('Enable this option to make this slider full-width', MPSL_TEXTDOMAIN),
                'default' => false
            ),
            'width' => array(
                'type' => 'number',
                'label' => __('Layers Grid Size', MPSL_TEXTDOMAIN),
                'label2' => __('Width:', MPSL_TEXTDOMAIN),
                'description' => __('Initial width of the layers', MPSL_TEXTDOMAIN),
//                'pattern' => '/^(0|[1-9][0-9]*)$/',
                'default' => 960,
                'min' => 0,
//                'disabled' => false
            ),
            'height' => array(
                'type' => 'number',
                'label2' => __('Height:', MPSL_TEXTDOMAIN),
                'description' => __('Initial height of the layers', MPSL_TEXTDOMAIN),
                'default' => 350,
                'min' => 0,
//                'disabled' => false
            ),
            /*'min_height' => array(
                'type' => 'number',
                'label2' => __('Min. Height:'),
                'default' => 500
            ),*/
            'enable_timer' => array(
                'type' => 'checkbox',
                'label2' => __('Enable Slideshow', MPSL_TEXTDOMAIN),
                'default' => true,
//                'disabled' => false
            ),
            'slider_delay' => array(
                'type' => 'text',
                'label' => __('Slideshow Delay:', MPSL_TEXTDOMAIN),
                'description' => __('The time one slide stays on the screen in milliseconds', MPSL_TEXTDOMAIN),
                'default' => 7000
            ),
            'hover_timer' => array(
                'type' => 'checkbox',
                'label2' => __('Pause on Hover', MPSL_TEXTDOMAIN),
                'description' => __('Pause slideshow when hover the slider', MPSL_TEXTDOMAIN),
                'default' => false
            ),
            'timer_reverse' => array(
                'type' => 'checkbox',
                'label2' => __('Reverse order of the slides', MPSL_TEXTDOMAIN),
                'description' => __('Animate slides in the reverse order', MPSL_TEXTDOMAIN),
                'default' => false
            ),

            'counter' => array(
                'type' => 'checkbox',
                'label2' => __('Show counter', MPSL_TEXTDOMAIN),
                'description' => __('Displays the number of slides', MPSL_TEXTDOMAIN),
                'default' => false
            ),
//            'slider_layout' => array(
//                'type' => 'select',
//                'label' => __('Slider Layout', MPSL_TEXTDOMAIN),
//                'default' => 'auto',
//                'list' => array(
//                    'auto' => __('Auto', MPSL_TEXTDOMAIN)
//                )
//            ),
//            'description' => array(
//                'type' => 'textarea',
//                'label' => __('Description :', MPSL_TEXTDOMAIN),
//                'description' => __('Write some description', MPSL_TEXTDOMAIN),
//                'default' => 'Default description',
////                'disabled' => false,
//            ),
//            'test' => array(
//                'type' => 'select',
//                'label' => __('Test dependency', MPSL_TEXTDOMAIN),
//                'default' => 'off',
//                'list' => array(
//                    'on' => 'On',
//                    'off' => 'Off'
//                ),
//            ),
//            'test_dependency' => array(
//                'type' => 'text',
//                'label' => __('Test dependency input', MPSL_TEXTDOMAIN),
//                'default' => 'visible',
//                'dependency' => array(
//                    'parameter' => 'test',
//                    'value' => 'on'
//                ),
//            ),
//            'radio_group' => array(
//                'type' => 'radio_group',
//                'label' => __('Test radiogroup', MPSL_TEXTDOMAIN),
//                'default' => 'one',
//                'list' => array(
//                    'one' => 'One',
//                    'two' => 'Two',
//                    'three' => 'Three',
//                )
//            ),
        )
    ),
//    'general' => array(
//        'title' => __('General Settings', MPSL_TEXTDOMAIN),
//        'icon' => null,
//        'description' => __('General description', MPSL_TEXTDOMAIN),
//        'options' => array(
//        )
//    ),

);